"""Validation threshold selection and binary metric calculation."""
import numpy as np


def binary_metrics(y_true, probabilities, threshold: float):
    y_true = np.asarray(y_true, dtype=int)
    predictions = (np.asarray(probabilities) >= threshold).astype(int)
    tn = int(np.sum((y_true == 0) & (predictions == 0)))
    fp = int(np.sum((y_true == 0) & (predictions == 1)))
    fn = int(np.sum((y_true == 1) & (predictions == 0)))
    tp = int(np.sum((y_true == 1) & (predictions == 1)))
    return {"threshold": float(threshold), "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
            "precision": float(tp / (tp + fp)) if tp + fp else 0.0,
            "recall": float(tp / (tp + fn)) if tp + fn else 0.0, "support_positive": int(sum(y_true))}


def choose_threshold(y_true, probabilities):
    candidates = [i / 100 for i in range(10, 91, 5)]
    return max(candidates, key=lambda t: (binary_metrics(y_true, probabilities, t)["recall"], binary_metrics(y_true, probabilities, t)["precision"]))


def precision_recall_points(y_true, probabilities):
    """Return a compact sampled precision/recall curve for saved experiment outputs."""
    thresholds = np.linspace(0.0, 1.0, 101)
    points = []
    for threshold in thresholds:
        metric = binary_metrics(y_true, probabilities, threshold)
        points.append({"threshold": threshold, "precision": metric["precision"], "recall": metric["recall"]})
    return points


def warning_lead_time(events, predictions, *, horizon_hours=24, threshold=.5):
    """Match each event once to its earliest positive probability within the prior horizon.

    `events` requires device_id and failure_time. `predictions` requires device_id,
    prediction_time, and probability. Misses are reported explicitly; lead time
    is averaged over detected events only.
    """
    import pandas as pd
    event_data = pd.DataFrame(events).copy()
    pred_data = pd.DataFrame(predictions).copy()
    event_data["failure_time"] = pd.to_datetime(event_data["failure_time"], utc=True)
    pred_data["prediction_time"] = pd.to_datetime(pred_data["prediction_time"], utc=True)
    leads = []
    missed = 0
    horizon = pd.Timedelta(hours=horizon_hours)
    for event in event_data.itertuples(index=False):
        candidates = pred_data[(pred_data.device_id == event.device_id) &
                               (pred_data.prediction_time < event.failure_time) &
                               (pred_data.prediction_time >= event.failure_time - horizon) &
                               (pred_data.probability >= threshold)]
        if candidates.empty:
            missed += 1
            continue
        first_time = candidates.prediction_time.min()
        leads.append((event.failure_time - first_time).total_seconds() / 3600)
    return {"failure_events": int(len(event_data)), "detected_events": int(len(leads)), "missed_events": int(missed),
            "mean_lead_time_hours": float(np.mean(leads)) if leads else None,
            "median_lead_time_hours": float(np.median(leads)) if leads else None}
