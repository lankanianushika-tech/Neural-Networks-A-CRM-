"""Model loading and shared preprocessing for prediction requests."""
from __future__ import annotations
import json
from pathlib import Path
import joblib, numpy as np, pandas as pd, yaml
from .features import FEATURE_NAMES, add_features
from .schema import validate_telemetry


class Predictor:
    def __init__(self, model_dir="models", model_name="lstm"):
        self.model_dir=Path(model_dir); self.model_name=model_name
        self.manifest=json.loads((self.model_dir/'model_manifest.json').read_text(encoding='utf-8'))
        self.config=yaml.safe_load((self.model_dir/'feature_config.yaml').read_text(encoding='utf-8'))
        self.scaler=joblib.load(self.model_dir/'scaler.joblib')
        import tensorflow as tf
        self.model=tf.keras.models.load_model(self.model_dir/f'{model_name}_best.keras')
        self.model_info=self.manifest['models'][model_name]

    def predict(self, telemetry: pd.DataFrame):
        interval=self.config['sampling_interval_minutes']
        data=validate_telemetry(telemetry,interval,require_ordered=True).reset_index(drop=True)
        if data.device_id.nunique()!=1: raise ValueError('Provide telemetry for exactly one device')
        length=self.model_info['window_samples']
        feature_history=int(self.config['feature_window_days']*24*60/interval)
        expected=feature_history + length - 1
        if len(data)<expected: raise ValueError(f'At least {expected} consecutive samples are required to calculate causal rolling features')
        if not (data.timestamp.diff().dropna()==pd.Timedelta(minutes=interval)).all(): raise ValueError('Telemetry must contain consecutive samples at the configured interval')
        featured=add_features(data,sampling_interval_minutes=interval,feature_window_days=self.config['feature_window_days'],volatility_window_samples=self.config['latency_volatility_window_samples'],reference_temperature_c=self.config['thermal_reference_temperature_c'])
        values=featured[FEATURE_NAMES].dropna().tail(length)
        if len(values)!=length: raise ValueError(f'Unable to form a complete {length}-sample model window')
        scaled=self.scaler.transform(values).astype(np.float32)[None,...]
        probability=float(self.model.predict(scaled,verbose=0).ravel()[0])
        return {'probability':probability,'model_version':self.model_info['version'],'prediction_horizon_minutes':self.manifest['prediction_horizon_minutes'],'generated_at':data.timestamp.iloc[-1].isoformat()}
