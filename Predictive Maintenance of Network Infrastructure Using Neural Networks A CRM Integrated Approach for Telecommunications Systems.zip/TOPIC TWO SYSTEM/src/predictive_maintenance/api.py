"""FastAPI prediction service and local mock CRM endpoints."""
from __future__ import annotations
import os
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Literal
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from .alerts import alert_for_prediction
from .store import AlertStore

store=AlertStore(os.getenv('MOCK_CRM_DB','data/mock_crm.sqlite3'))
predictor=None

class TelemetryRow(BaseModel):
    timestamp: datetime
    error_rate: float=Field(ge=0)
    latency_ms: float=Field(ge=0)
    temperature_c: float
    traffic_load: float=Field(ge=0,le=1)

class PredictionRequest(BaseModel):
    device_id: str
    telemetry: list[TelemetryRow]
    create_alert: bool=True

class StatusRequest(BaseModel):
    status: Literal['reviewed','actioned','false_alarm','closed']
    actor: str='reviewer'
    note: str|None=None

@asynccontextmanager
async def lifespan(_app):
    global predictor
    model_dir=os.getenv('MODEL_DIR','models')
    if os.path.exists(os.path.join(model_dir,'model_manifest.json')):
        from .inference import Predictor
        try: predictor=Predictor(model_dir,os.getenv('MODEL_NAME','lstm'))
        except Exception: predictor=None
    yield

app=FastAPI(title='Telecom Predictive Maintenance API',version='0.1.0',lifespan=lifespan)

@app.get('/health')
def health():
    return {'status':'ok','model_loaded':predictor is not None}

@app.post('/predict')
def predict(request: PredictionRequest):
    if predictor is None: raise HTTPException(503,'No trained model is loaded. Train the model and restart the API.')
    data=pd.DataFrame([{'device_id':request.device_id,**row.model_dump()} for row in request.telemetry])
    try: result=predictor.predict(data)
    except (ValueError,KeyError) as exc: raise HTTPException(422,str(exc)) from exc
    threshold=float(predictor.model_info['threshold'])
    cfg=predictor.config['alert_policy']
    alert=alert_for_prediction(device_id=request.device_id,generated_at=pd.Timestamp(result['generated_at']).to_pydatetime(),probability=result['probability'],threshold=threshold,model_version=result['model_version'],policy_version=cfg['version'],medium_probability=cfg['medium_probability'],contributing_features=[])
    record=store.create_or_update(alert) if request.create_alert and alert else None
    return {**result,'threshold':threshold,'alert':record}

@app.get('/alerts')
def list_alerts(limit: int=100): return store.list(max(1,min(limit,500)))

@app.get('/alerts/{alert_id}')
def get_alert(alert_id: str):
    item=store.get(alert_id)
    if item is None: raise HTTPException(404,'Alert not found')
    return item

@app.patch('/alerts/{alert_id}/status')
def update_alert_status(alert_id: str, request: StatusRequest):
    item=store.update_status(alert_id,request.status,request.actor,request.note)
    if item is None: raise HTTPException(404,'Alert not found')
    return item
