"""Train the documented feed-forward and LSTM models from a telemetry CSV."""
from __future__ import annotations
import argparse, hashlib, json, platform, random, sys, time
from datetime import datetime, timezone
from pathlib import Path
import joblib, numpy as np, pandas as pd, yaml
from sklearn.preprocessing import StandardScaler
from sklearn.utils.class_weight import compute_class_weight
from .features import FEATURE_NAMES, add_features, label_failures
from .metrics import binary_metrics, choose_threshold, precision_recall_points, warning_lead_time
from .schema import data_quality_report, validate_telemetry
from .simulator import simulate_telemetry
from .windows import make_windows, temporal_split


def run_training(input_csv=None, output_dir="models", config_path="config/default.yaml", epochs=30):
    try:
        import tensorflow as tf
        from tensorflow import keras
        from tensorflow.keras import layers
    except ImportError as exc:
        raise RuntimeError("TensorFlow is optional; install with: pip install -e '.[training]'") from exc
    cfg=yaml.safe_load(Path(config_path).read_text(encoding="utf-8"))
    seed=int(cfg['random_seed']); random.seed(seed); np.random.seed(seed); tf.random.set_seed(seed)
    out=Path(output_dir); out.mkdir(parents=True,exist_ok=True)
    raw=pd.read_csv(input_csv, parse_dates=['timestamp']) if input_csv else simulate_telemetry(seed=seed)
    quality=data_quality_report(raw,cfg['sampling_interval_minutes'])
    (out/'data_quality_report.json').write_text(json.dumps(quality,indent=2),encoding='utf-8')
    raw=validate_telemetry(raw, cfg['sampling_interval_minutes'], require_ordered=False)
    raw=raw.sort_values(['device_id','timestamp']).reset_index(drop=True)
    full=add_features(raw, sampling_interval_minutes=cfg['sampling_interval_minutes'], feature_window_days=cfg['feature_window_days'], volatility_window_samples=cfg['latency_volatility_window_samples'], reference_temperature_c=cfg['thermal_reference_temperature_c'])
    full=label_failures(full, sampling_interval_minutes=cfg['sampling_interval_minutes'], prediction_horizon_minutes=cfg['prediction_horizon_minutes'])
    # Exclude rows without complete past feature history before defining split boundaries.
    feature_excluded=int(full[FEATURE_NAMES].isna().any(axis=1).sum())
    label_unknown=int(full.label.isna().sum())
    quality.update({'rows_excluded_for_feature_history':feature_excluded,'unknown_labels_excluded':label_unknown,
                    'label_counts':{str(int(k)):int(v) for k,v in full.label.dropna().value_counts().sort_index().items()}})
    (out/'data_quality_report.json').write_text(json.dumps(quality,indent=2),encoding='utf-8')
    full=full.dropna(subset=FEATURE_NAMES).reset_index(drop=True)
    full=temporal_split(full, **cfg['temporal_split'])
    split_audit={}
    for split, rows in full.groupby('split'):
        split_audit[split]={'rows':int(len(rows)),'devices':int(rows.device_id.nunique()),
            'positive_labels':int(rows.label.fillna(0).sum()),'unknown_labels':int(rows.label.isna().sum()),
            'positive_rate':float(rows.label.mean()) if rows.label.notna().any() else None,
            'earliest_timestamp':str(rows.timestamp.min()),'latest_timestamp':str(rows.timestamp.max())}
    scaler=StandardScaler()
    train_rows=full[(full.split=='train') & full.label.notna()].dropna(subset=FEATURE_NAMES)
    if train_rows.empty: raise ValueError("No training rows remain; provide sufficient telemetry history and events")
    scaler.fit(train_rows[FEATURE_NAMES]); full.loc[:,FEATURE_NAMES]=scaler.transform(full[FEATURE_NAMES].fillna(0))
    joblib.dump(scaler,out/'scaler.joblib')
    cw_labels=np.unique(train_rows.label.astype(int)); weights=compute_class_weight('balanced',classes=cw_labels,y=train_rows.label.astype(int)); class_weight={int(k):float(v) for k,v in zip(cw_labels,weights)}
    metrics={}; models={}
    for name,length,kind in [('baseline',cfg['baseline_window_samples'],'baseline'),('lstm',cfg['lstm_window_samples'],'lstm')]:
        # Build each temporal partition independently so windows never cross boundaries.
        arrays={}
        for split in ('train','validation','test'):
            section=full[full.split==split].sort_values(['device_id','timestamp'])
            arrays[split]=make_windows(section,length=length,feature_names=FEATURE_NAMES)
        (xtr,ytr,_),(xv,yv,_),(xt,yt,manifest)=arrays['train'],arrays['validation'],arrays['test']
        if len(xtr)==0 or len(xv)==0 or len(xt)==0: raise ValueError(f"Insufficient valid windows for {name}; increase dataset duration")
        if kind=='baseline':
            model=keras.Sequential([layers.Input(shape=(length,len(FEATURE_NAMES))),layers.Flatten(),layers.Dense(64,activation='relu'),layers.Dropout(.3),layers.Dense(32,activation='relu'),layers.Dropout(.3),layers.Dense(1,activation='sigmoid')])
        else:
            model=keras.Sequential([layers.Input(shape=(length,len(FEATURE_NAMES))),layers.LSTM(50,return_sequences=True),layers.LSTM(25),layers.Dense(1,activation='sigmoid')])
        model.compile(optimizer=keras.optimizers.Adam(),loss='binary_crossentropy',metrics=[keras.metrics.Precision(name='precision'),keras.metrics.Recall(name='recall')])
        path=out/f'{name}_best.keras'
        training_started=time.perf_counter()
        history=model.fit(xtr,ytr,validation_data=(xv,yv),epochs=epochs,batch_size=64,class_weight=class_weight,callbacks=[keras.callbacks.ModelCheckpoint(str(path),monitor='val_loss',save_best_only=True),keras.callbacks.EarlyStopping(monitor='val_loss',patience=6,restore_best_weights=True)],verbose=2)
        training_seconds=round(time.perf_counter()-training_started,3)
        model=keras.models.load_model(path)
        valp=model.predict(xv,verbose=0).ravel(); threshold=choose_threshold(yv,valp)
        testp=model.predict(xt,verbose=0).ravel()
        test_metrics=binary_metrics(yt,testp,threshold)
        metrics[name]={'validation':binary_metrics(yv,valp,threshold),'test':test_metrics,'threshold_selected_on':'validation',
            'precision_recall_curve':precision_recall_points(yt,testp)}
        events=full[(full.split=='test') & (full.failure_event==1)][['device_id','timestamp']].rename(columns={'timestamp':'failure_time'})
        predictions=manifest[['device_id','input_end']].copy().rename(columns={'input_end':'prediction_time'})
        predictions['probability']=testp
        metrics[name]['warning_lead_time']=warning_lead_time(events,predictions,horizon_hours=cfg['prediction_horizon_minutes']/60,threshold=threshold)
        manifest.to_csv(out/f'{name}_test_windows.csv',index=False)
        pd.DataFrame({'label':yt,'probability':testp}).to_csv(out/f'{name}_test_predictions.csv',index=False)
        models[name]={'version':f'{name}-v1','threshold':threshold,'window_samples':length,
                      'epochs_completed':len(history.history['loss']),'training_seconds':training_seconds}
    (out/'metrics.json').write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    (out/'split_audit.json').write_text(json.dumps(split_audit,indent=2),encoding='utf-8')
    joblib.dump(scaler,out/'scaler.joblib')
    manifest_data={'trained_at':datetime.now(timezone.utc).isoformat(),'code_version':'0.1.0','git_commit':None,
        'seed':seed,'features':FEATURE_NAMES,'sampling_interval_minutes':cfg['sampling_interval_minutes'],
        'prediction_horizon_minutes':cfg['prediction_horizon_minutes'],'thermal_stress_is_experimental_proxy':cfg['thermal_stress_is_experimental_proxy'],
        'data_source':{'source_type_counts':{str(k):int(v) for k,v in raw.get('source_type',pd.Series('unspecified',index=raw.index)).value_counts().items()},
                       'row_count':int(len(raw)),'dataset_sha256':hashlib.sha256(raw.to_csv(index=False).encode('utf-8')).hexdigest()},
        'split_definitions':cfg['temporal_split'],'split_audit':split_audit,
        'training':{'optimizer':'Adam','learning_rate':0.001,'batch_size':64,'max_epochs':int(epochs),
                    'early_stopping':{'monitor':'val_loss','patience':6,'restore_best_weights':True},'class_weight':class_weight,
                    'architecture':{'baseline':'MLP(64,32), dropout=0.3','lstm':'LSTM(50,25)'}},
        'runtime':{'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'pandas':pd.__version__,'tensorflow':tf.__version__},
        'models':models,'metrics':metrics}
    (out/'model_manifest.json').write_text(json.dumps(manifest_data,indent=2),encoding='utf-8')
    (out/'feature_config.yaml').write_text(yaml.safe_dump(cfg,sort_keys=False),encoding='utf-8')
    print(json.dumps(metrics,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--input'); parser.add_argument('--output',default='models'); parser.add_argument('--config',default='config/default.yaml'); parser.add_argument('--epochs',type=int,default=30)
    args=parser.parse_args(); run_training(args.input,args.output,args.config,args.epochs)
