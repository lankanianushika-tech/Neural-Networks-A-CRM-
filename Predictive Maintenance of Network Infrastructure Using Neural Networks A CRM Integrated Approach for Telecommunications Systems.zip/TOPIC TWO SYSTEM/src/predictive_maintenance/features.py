"""Shared causal feature engineering for training and inference."""
from __future__ import annotations

import numpy as np
import pandas as pd

FEATURE_NAMES = ["error_rate", "latency_ms", "temperature_c", "traffic_load", "error_rate_gradient", "latency_volatility", "thermal_stress"]


def add_features(frame: pd.DataFrame, *, sampling_interval_minutes: int = 5, feature_window_days: int = 7,
                 volatility_window_samples: int = 12, reference_temperature_c: float = 60.0) -> pd.DataFrame:
    pieces = []
    window = max(2, int(feature_window_days * 24 * 60 / sampling_interval_minutes))
    for _, source in frame.groupby("device_id", sort=False):
        part = source.copy()
        # Least-squares slope per hour from current and prior observations only.
        x = np.arange(window, dtype=float)
        x_center = x - x.mean()
        denom = float(np.dot(x_center, x_center))
        part["error_rate_gradient"] = part.error_rate.rolling(window, min_periods=window).apply(
            lambda y: float(np.dot(x_center, y - np.mean(y)) / denom) * (60 / sampling_interval_minutes), raw=True
        )
        part["latency_volatility"] = part.latency_ms.rolling(volatility_window_samples, min_periods=volatility_window_samples).std(ddof=0)
        part["thermal_stress"] = np.maximum(part.temperature_c - reference_temperature_c, 0.0) * part.traffic_load
        pieces.append(part)
    return pd.concat(pieces).sort_index() if pieces else frame.copy()


def label_failures(frame: pd.DataFrame, *, sampling_interval_minutes: int = 5, prediction_horizon_minutes: int = 1440) -> pd.DataFrame:
    """Label 1 when a future observed failure is within (t, t+horizon]; unsupported tail is NA."""
    horizon = int(prediction_horizon_minutes / sampling_interval_minutes)
    output = frame.copy()
    labels = pd.Series(index=output.index, dtype="Int64")
    for _, group in output.groupby("device_id", sort=False):
        failures = group.get("failure_event", pd.Series(0, index=group.index)).fillna(0).astype(int).to_numpy()
        values = np.full(len(group), -1, dtype=int)
        for i in range(max(0, len(group) - horizon)):
            values[i] = int(np.any(failures[i + 1:i + horizon + 1] == 1))
        labels.loc[group.index] = pd.array([pd.NA if x == -1 else x for x in values], dtype="Int64")
    output["label"] = labels
    return output
