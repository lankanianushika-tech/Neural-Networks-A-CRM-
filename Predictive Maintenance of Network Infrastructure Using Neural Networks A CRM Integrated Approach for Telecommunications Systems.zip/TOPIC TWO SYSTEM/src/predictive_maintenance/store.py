"""SQLite-backed mock CRM with idempotent open-alert upserts and audit trail."""
from __future__ import annotations
import json, sqlite3, uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

STATUSES = {"new", "reviewed", "actioned", "false_alarm", "closed"}


class AlertStore:
    def __init__(self, path="data/mock_crm.sqlite3"):
        self.path = str(path); Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS alerts (
              alert_id TEXT PRIMARY KEY, device_id TEXT NOT NULL, generated_at TEXT NOT NULL,
              window_start TEXT NOT NULL, window_end TEXT NOT NULL, confidence REAL NOT NULL,
              priority TEXT NOT NULL, contributing_features TEXT NOT NULL, model_version TEXT NOT NULL,
              policy_version TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
              attempt_count INTEGER NOT NULL DEFAULT 0, last_delivery_error TEXT)""")
            db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_open_alert ON alerts(device_id, model_version, window_start, window_end) WHERE status IN ('new','reviewed','actioned')")
            db.execute("""CREATE TABLE IF NOT EXISTS alert_audit (
              audit_id INTEGER PRIMARY KEY AUTOINCREMENT, alert_id TEXT NOT NULL, old_status TEXT, new_status TEXT NOT NULL,
              changed_at TEXT NOT NULL, actor TEXT NOT NULL, note TEXT)""")

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path)
        db.row_factory = sqlite3.Row
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def create_or_update(self, alert):
        now = datetime.now(timezone.utc).isoformat()
        with self.connect() as db:
            row = db.execute("SELECT * FROM alerts WHERE device_id=? AND model_version=? AND window_start=? AND window_end=? AND status IN ('new','reviewed','actioned')", (alert['device_id'], alert['model_version'], str(alert['window_start']), str(alert['window_end']))).fetchone()
            if row:
                db.execute("UPDATE alerts SET confidence=?,priority=?,generated_at=?,updated_at=? WHERE alert_id=?", (alert['confidence'], alert['priority'], str(alert['generated_at']), now, row['alert_id']))
                alert_id = row['alert_id']
            else:
                alert_id = str(uuid.uuid4())
                db.execute("INSERT INTO alerts(alert_id,device_id,generated_at,window_start,window_end,confidence,priority,contributing_features,model_version,policy_version,status,created_at,updated_at,attempt_count) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,1)",
                    (alert_id, alert['device_id'], str(alert['generated_at']), str(alert['window_start']), str(alert['window_end']), alert['confidence'], alert['priority'], json.dumps(alert.get('contributing_features', [])), alert['model_version'], alert['policy_version'], alert['status'], now, now))
            return self.get(alert_id, db)

    def get(self, alert_id, db=None):
        if db is None:
            with self.connect() as connection:
                return self.get(alert_id, connection)
        row = db.execute("SELECT * FROM alerts WHERE alert_id=?", (alert_id,)).fetchone()
        if not row: return None
        result = dict(row); result['contributing_features'] = json.loads(result.pop('contributing_features')); return result

    def list(self, limit=100):
        with self.connect() as db:
            rows = db.execute("SELECT * FROM alerts ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
            result=[]
            for row in rows:
                item=dict(row); item['contributing_features']=json.loads(item.pop('contributing_features')); result.append(item)
            return result

    def update_status(self, alert_id, status, actor="reviewer", note=None):
        if status not in STATUSES: raise ValueError(f"status must be one of {sorted(STATUSES)}")
        now = datetime.now(timezone.utc).isoformat()
        with self.connect() as db:
            row=db.execute("SELECT status FROM alerts WHERE alert_id=?",(alert_id,)).fetchone()
            if not row: return None
            db.execute("UPDATE alerts SET status=?,updated_at=? WHERE alert_id=?",(status,now,alert_id))
            db.execute("INSERT INTO alert_audit(alert_id,old_status,new_status,changed_at,actor,note) VALUES(?,?,?,?,?,?)",(alert_id,row['status'],status,now,actor,note))
        return self.get(alert_id)
