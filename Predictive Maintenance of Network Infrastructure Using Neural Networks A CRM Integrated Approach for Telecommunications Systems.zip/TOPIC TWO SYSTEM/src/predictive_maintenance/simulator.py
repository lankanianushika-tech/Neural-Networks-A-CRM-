"""Deterministic synthetic telemetry generator for exercising the prototype."""
from __future__ import annotations
import numpy as np
import pandas as pd


def simulate_telemetry(devices: int = 4, days: int = 30, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    samples = days * 24 * 12
    start = pd.Timestamp.now(tz="UTC").floor("5min") - pd.Timedelta(minutes=5 * samples)
    rows = []
    for d in range(devices):
        failure_at = int(rng.integers(int(samples * .55), int(samples * .88)))
        phase = np.arange(samples) / samples * 2 * np.pi
        degradation = np.clip((np.arange(samples) - (failure_at - 3 * 24 * 12)) / (3 * 24 * 12), 0, 1)
        noise = lambda scale: rng.normal(0, scale, samples)
        error = np.clip(.004 + .025 * degradation + .002 * np.sin(phase) + noise(.002), 0, 1)
        latency = np.clip(28 + 30 * degradation + 4 * np.sin(phase * 2) + noise(3), 1, None)
        temp = 48 + 20 * degradation + 3 * np.sin(phase) + noise(1.5)
        load = np.clip(.55 + .18 * np.sin(phase + d) + noise(.08), 0, 1)
        events = np.zeros(samples, dtype=int); events[failure_at] = 1
        for i in range(samples):
            rows.append((f"sim-device-{d+1:04d}", start + pd.Timedelta(minutes=5*i), error[i], latency[i], temp[i], load[i], events[i], "simulated"))
    return pd.DataFrame(rows, columns=["device_id", "timestamp", "error_rate", "latency_ms", "temperature_c", "traffic_load", "failure_event", "source_type"])


if __name__ == "__main__":
    from pathlib import Path
    target = Path("data/raw/synthetic.csv")
    target.parent.mkdir(parents=True, exist_ok=True)
    data = simulate_telemetry()
    data.to_csv(target, index=False)
    print(f"Wrote {len(data)} rows to {target}")
