"""Input schema and data quality validation."""
from __future__ import annotations

import pandas as pd
import numpy as np

REQUIRED_COLUMNS = ["device_id", "timestamp", "error_rate", "latency_ms", "temperature_c", "traffic_load"]
TELEMETRY_COLUMNS = ["error_rate", "latency_ms", "temperature_c", "traffic_load"]


def data_quality_report(frame: pd.DataFrame, sampling_interval_minutes: int = 5) -> dict:
    """Summarize input problems without modifying or exposing telemetry values."""
    missing_columns = sorted(set(REQUIRED_COLUMNS) - set(frame.columns))
    report = {"input_rows": int(len(frame)), "missing_columns": missing_columns,
              "rows_missing_required_values": int(frame[[c for c in REQUIRED_COLUMNS if c in frame]].isna().any(axis=1).sum()) if frame.columns.intersection(REQUIRED_COLUMNS).size else int(len(frame)),
              "duplicate_device_timestamp_rows": 0, "out_of_order_rows": 0, "irregular_intervals": 0, "interpolated_gaps": 0, "excluded_gaps": 0,
              "invalid_timestamps": 0, "out_of_range_rows": 0}
    if "timestamp" not in frame:
        return report
    parsed = pd.to_datetime(frame.timestamp, utc=True, errors="coerce")
    report["invalid_timestamps"] = int(parsed.isna().sum())
    if "device_id" in frame:
        keys = pd.DataFrame({"device_id": frame.device_id.astype(str), "timestamp": parsed})
        report["duplicate_device_timestamp_rows"] = int(keys.duplicated().sum())
        original_order = frame.loc[parsed.notna(), ["device_id"]].copy()
        original_order["timestamp"] = parsed.loc[parsed.notna()]
        for _, group in original_order.groupby("device_id", sort=False):
            report["out_of_order_rows"] += int((group.timestamp.diff() < pd.Timedelta(0)).sum())
        valid = frame.loc[parsed.notna()].copy(); valid["timestamp"] = parsed.loc[parsed.notna()]
        valid = valid.sort_values(["device_id", "timestamp"])
        for _, group in valid.groupby("device_id", sort=False):
            intervals = group.timestamp.diff().dropna()
            irregular = intervals != pd.Timedelta(minutes=sampling_interval_minutes)
            report["irregular_intervals"] += int(irregular.sum())
            report["excluded_gaps"] += int((intervals[irregular] > pd.Timedelta(minutes=sampling_interval_minutes)).sum())
    numeric = [c for c in TELEMETRY_COLUMNS if c in frame]
    if numeric:
        converted = frame[numeric].apply(pd.to_numeric, errors="coerce")
        bad = ~np.isfinite(converted.to_numpy(dtype=float)).all(axis=1)
        for col, condition in (("error_rate", lambda s: s < 0), ("latency_ms", lambda s: s < 0),
                               ("traffic_load", lambda s: (s < 0) | (s > 1))):
            if col in converted:
                bad |= condition(converted[col]).fillna(True).to_numpy()
        report["out_of_range_rows"] = int(bad.sum())
    return report


def validate_telemetry(frame: pd.DataFrame, sampling_interval_minutes: int = 5, *, require_ordered: bool = True) -> pd.DataFrame:
    missing = sorted(set(REQUIRED_COLUMNS) - set(frame.columns))
    if missing:
        raise ValueError(f"Missing required columns: {', '.join(missing)}")
    data = frame.copy()
    if data[REQUIRED_COLUMNS].isna().any().any():
        raise ValueError("Required telemetry fields cannot be missing")
    data["device_id"] = data["device_id"].astype(str)
    data["timestamp"] = pd.to_datetime(data["timestamp"], utc=True, errors="coerce")
    if data.timestamp.isna().any():
        raise ValueError("timestamp contains invalid values")
    for column in TELEMETRY_COLUMNS:
        data[column] = pd.to_numeric(data[column], errors="coerce")
        if data[column].isna().any():
            raise ValueError(f"{column} must contain numeric values")
    if not np.isfinite(data[TELEMETRY_COLUMNS].to_numpy(dtype=float)).all():
        raise ValueError("Telemetry values must be finite")
    if (data.error_rate < 0).any() or (data.latency_ms < 0).any() or (data.traffic_load < 0).any() or (data.traffic_load > 1).any():
        raise ValueError("Values out of range: error_rate/latency_ms must be nonnegative and traffic_load must be in [0, 1]")
    if data.duplicated(["device_id", "timestamp"]).any():
        raise ValueError("Duplicate (device_id, timestamp) rows found")
    if require_ordered:
        for device, group in data.groupby("device_id", sort=False):
            ts = group.timestamp
            if not ts.is_monotonic_increasing:
                raise ValueError(f"Timestamps are not ordered for device {device}")
            if len(ts) > 1 and not (ts.diff().dropna() == pd.Timedelta(minutes=sampling_interval_minutes)).all():
                raise ValueError(f"Irregular sampling interval for device {device}")
    return data
