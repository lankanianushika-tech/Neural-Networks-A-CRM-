"""Versioned alert decision and priority policy."""
from datetime import timedelta


def alert_for_prediction(*, device_id: str, generated_at, probability: float, threshold: float, model_version: str,
                         policy_version: str = "alert-policy-v1", medium_probability: float = .35, contributing_features=None):
    if probability < threshold:
        return None
    priority = "high" if probability >= max(.75, threshold) else ("medium" if probability >= medium_probability else "low")
    return {"device_id": device_id, "generated_at": generated_at, "window_start": generated_at,
            "window_end": generated_at + timedelta(hours=24), "confidence": probability, "priority": priority,
            "contributing_features": contributing_features or [], "model_version": model_version,
            "policy_version": policy_version, "status": "new"}
