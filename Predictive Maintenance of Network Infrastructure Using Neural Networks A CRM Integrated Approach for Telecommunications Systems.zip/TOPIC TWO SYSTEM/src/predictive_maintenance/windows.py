"""Contiguous fixed-length windows and temporal partitioning."""
from __future__ import annotations

import numpy as np
import pandas as pd


def make_windows(frame: pd.DataFrame, *, length: int, feature_names: list[str], label_column: str = "label"):
    xs, ys, index = [], [], []
    for device, group in frame.groupby("device_id", sort=False):
        group = group.sort_values("timestamp")
        values = group[feature_names].to_numpy(dtype=np.float32)
        labels = group[label_column].to_numpy()
        times = group.timestamp.to_numpy()
        for end in range(length - 1, len(group)):
            start = end - length + 1
            y = labels[end]
            if pd.isna(y):
                continue
            if end > start and not np.all(np.diff(times[start:end + 1]) == np.timedelta64(5, "m")):
                continue
            if not np.isfinite(values[start:end + 1]).all():
                continue
            xs.append(values[start:end + 1]); ys.append(int(y))
            index.append({"device_id": device, "input_start": str(times[start]), "input_end": str(times[end]), "target_time": str(times[end]), "label": int(y)})
    return np.asarray(xs, dtype=np.float32), np.asarray(ys, dtype=np.int32), pd.DataFrame(index)


def temporal_split(frame: pd.DataFrame, train: float = .70, validation: float = .10, test: float | None = None):
    """Split each device in chronological order and annotate rows with split."""
    if train <= 0 or validation < 0 or train + validation >= 1:
        raise ValueError("Temporal split requires train > 0, validation >= 0, and train + validation < 1")
    if test is not None and not np.isclose(train + validation + test, 1.0):
        raise ValueError("Train, validation, and test proportions must sum to 1")
    out = frame.copy(); out["split"] = ""
    for _, group in out.groupby("device_id", sort=False):
        ordered = group.sort_values("timestamp"); n = len(ordered)
        a, b = int(n * train), int(n * (train + validation))
        out.loc[ordered.index[:a], "split"] = "train"
        out.loc[ordered.index[a:b], "split"] = "validation"
        out.loc[ordered.index[b:], "split"] = "test"
    return out
