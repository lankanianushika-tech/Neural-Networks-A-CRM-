import pandas as pd
import pytest

from predictive_maintenance.schema import data_quality_report, validate_telemetry


def test_validation_flags_and_rejects_out_of_order_or_duplicate_samples():
    data = pd.DataFrame({"device_id": ["d1", "d1", "d1"],
        "timestamp": pd.to_datetime(["2026-01-01T00:00:00Z", "2026-01-01T00:10:00Z", "2026-01-01T00:05:00Z"]),
        "error_rate": [.01, .01, .01], "latency_ms": [30, 30, 30], "temperature_c": [50, 50, 50], "traffic_load": [.5, .5, .5]})
    report = data_quality_report(data)
    assert report["out_of_order_rows"] == 1
    with pytest.raises(ValueError, match="not ordered"):
        validate_telemetry(data)


def test_validation_rejects_non_finite_measurements():
    data = pd.DataFrame({"device_id": ["d1"], "timestamp": pd.to_datetime(["2026-01-01T00:00:00Z"]),
        "error_rate": [float("inf")], "latency_ms": [30], "temperature_c": [50], "traffic_load": [.5]})
    with pytest.raises(ValueError, match="finite"):
        validate_telemetry(data)
