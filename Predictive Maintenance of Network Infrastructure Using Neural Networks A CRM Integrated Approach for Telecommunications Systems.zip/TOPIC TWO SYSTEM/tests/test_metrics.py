import numpy as np
from predictive_maintenance.metrics import binary_metrics, choose_threshold, precision_recall_points, warning_lead_time


def test_confusion_metrics_match_counts_and_threshold_comes_from_candidates():
    metrics = binary_metrics(np.array([0, 0, 1, 1]), np.array([.1, .8, .4, .9]), .5)
    assert (metrics["tn"], metrics["fp"], metrics["fn"], metrics["tp"]) == (1, 1, 1, 1)
    assert metrics["precision"] == .5
    assert metrics["recall"] == .5
    threshold = choose_threshold(np.array([0, 0, 1, 1]), np.array([.1, .8, .4, .9]))
    assert threshold in [i / 100 for i in range(10, 91, 5)]
    assert precision_recall_points([0, 1], [.1, .9])[0]["recall"] == 1


def test_lead_time_uses_first_qualifying_alert_and_counts_misses():
    result = warning_lead_time(
        [{"device_id": "d1", "failure_time": "2026-01-02T00:00:00Z"}, {"device_id": "d2", "failure_time": "2026-01-02T00:00:00Z"}],
        [{"device_id": "d1", "prediction_time": "2026-01-01T12:00:00Z", "probability": .8},
         {"device_id": "d1", "prediction_time": "2026-01-01T18:00:00Z", "probability": .9}],
        threshold=.5,
    )
    assert result["detected_events"] == 1
    assert result["missed_events"] == 1
    assert result["mean_lead_time_hours"] == 12
