import numpy as np
import pandas as pd

from predictive_maintenance.features import add_features


def test_features_are_causal_and_expected_for_constant_signal():
    n = 2016 + 24
    frame = pd.DataFrame({
        "device_id": "d1",
        "timestamp": pd.date_range("2026-01-01", periods=n, freq="5min", tz="UTC"),
        "error_rate": 0.01,
        "latency_ms": 30.0,
        "temperature_c": 50.0,
        "traffic_load": 0.5,
    })
    first = add_features(frame)
    changed = frame.copy()
    changed.loc[n - 1, ["error_rate", "latency_ms", "temperature_c", "traffic_load"]] = [0.9, 400, 100, 1]
    second = add_features(changed)
    assert first.loc[n - 2, "error_rate_gradient"] == second.loc[n - 2, "error_rate_gradient"]
    assert first.loc[n - 1, "error_rate_gradient"] == 0
    assert first.loc[n - 1, "latency_volatility"] == 0
    assert first.loc[n - 1, "thermal_stress"] == 0
    assert first.loc[2014, "error_rate_gradient"] != first.loc[2014, "error_rate_gradient"]
