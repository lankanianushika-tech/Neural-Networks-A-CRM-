import numpy as np
import pandas as pd

from predictive_maintenance.features import label_failures
from predictive_maintenance.windows import make_windows


def test_failure_labels_use_future_horizon_and_exclude_unsupported_tail():
    n = 700
    frame = pd.DataFrame({"device_id": "d1", "timestamp": pd.date_range("2026-01-01", periods=n, freq="5min", tz="UTC"), "failure_event": 0})
    frame.loc[400, "failure_event"] = 1
    labelled = label_failures(frame)
    assert labelled.loc[112, "label"] == 1
    assert labelled.loc[400, "label"] == 0
    assert labelled.loc[12, "label"] == 0
    assert pd.isna(labelled.loc[412, "label"])
    assert pd.isna(labelled.loc[699, "label"])


def test_windows_keep_expected_shape_and_target():
    frame = pd.DataFrame({"device_id": "d1", "timestamp": pd.date_range("2026-01-01", periods=8, freq="5min", tz="UTC"), "f": np.arange(8), "label": 0})
    x, y, index = make_windows(frame, length=6, feature_names=["f"])
    assert x.shape == (3, 6, 1)
    assert y.tolist() == [0, 0, 0]
    assert index.iloc[0]["input_start"].startswith("2026-01-01")
