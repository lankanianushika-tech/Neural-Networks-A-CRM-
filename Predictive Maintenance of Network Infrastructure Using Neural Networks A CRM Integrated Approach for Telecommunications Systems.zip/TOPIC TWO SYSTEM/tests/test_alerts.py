from datetime import datetime, timezone
from predictive_maintenance.alerts import alert_for_prediction
from predictive_maintenance.store import AlertStore


def test_alert_threshold_deduplication_and_review_status(tmp_path):
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    assert alert_for_prediction(device_id="d1", generated_at=now, probability=.2, threshold=.5, model_version="v1") is None
    alert = alert_for_prediction(device_id="d1", generated_at=now, probability=.8, threshold=.5, model_version="v1")
    store = AlertStore(tmp_path / "crm.sqlite3")
    first = store.create_or_update(alert)
    second = store.create_or_update(alert)
    assert first["alert_id"] == second["alert_id"]
    reviewed = store.update_status(first["alert_id"], "reviewed", actor="tester", note="checked")
    assert reviewed["status"] == "reviewed"
    assert len(store.list()) == 1
