"""FastAPI prediction service and local mock CRM endpoints."""
from __future__ import annotations
import os
import base64, binascii, io, logging
from zipfile import BadZipFile
from pathlib import Path
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Literal
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from .alerts import alert_for_prediction
from .store import AlertStore

store=AlertStore(os.getenv('MOCK_CRM_DB','data/mock_crm.sqlite3'))
predictor=None

class TelemetryRow(BaseModel):
    timestamp: datetime
    error_rate: float=Field(ge=0)
    latency_ms: float=Field(ge=0)
    temperature_c: float
    traffic_load: float=Field(ge=0,le=1)

class PredictionRequest(BaseModel):
    device_id: str
    telemetry: list[TelemetryRow]
    create_alert: bool=True

class StatusRequest(BaseModel):
    status: Literal['reviewed','actioned','false_alarm','closed']
    actor: str='reviewer'
    note: str|None=None

class WorkbookRequest(BaseModel):
    filename: str
    content_base64: str
    sheet: str|None=None

REQUIRED_TELEMETRY = ['device_id','timestamp','error_rate','latency_ms','temperature_c','traffic_load']

def read_workbook(request: WorkbookRequest):
    try:
        data=base64.b64decode(request.content_base64,validate=True)
        if len(data)>15_000_000: raise ValueError('File exceeds 15 MB')
        if request.filename.lower().endswith('.csv'):
            frame=pd.read_csv(io.BytesIO(data)); sheets=['CSV']; selected='CSV'
        elif request.filename.lower().endswith('.xlsx'):
            book=pd.ExcelFile(io.BytesIO(data),engine='openpyxl'); sheets=book.sheet_names
            if request.sheet and request.sheet not in sheets: raise ValueError('Sheet not found')
            selected=request.sheet or sheets[0]
            if not request.sheet:
                for name in sheets:
                    headers=pd.read_excel(book,sheet_name=name,nrows=0).columns
                    normalized={str(c).strip().lower() for c in headers}
                    if set(REQUIRED_TELEMETRY).issubset(normalized):
                        selected=name
                        break
            frame=pd.read_excel(book,sheet_name=selected)
        else: raise ValueError('Choose an .xlsx or .csv file')
        frame.columns=[str(c).strip().lower() for c in frame.columns]
        if frame.columns.duplicated().any(): raise ValueError('Duplicate columns after normalizing names')
        return frame,sheets,selected
    except (ValueError, binascii.Error, ImportError, OSError, KeyError, BadZipFile) as exc:
        raise HTTPException(422,f'Unable to read file: {exc}') from exc

@asynccontextmanager
async def lifespan(_app):
    global predictor
    predictor=None
    model_dir=os.getenv('MODEL_DIR','models')
    if os.path.exists(os.path.join(model_dir,'model_manifest.json')):
        from .inference import Predictor
        try: predictor=Predictor(model_dir,os.getenv('MODEL_NAME','lstm'))
        except Exception:
            logging.exception('Model loading failed')
            predictor=None
    yield

app=FastAPI(title='Telecom Predictive Maintenance API',version='0.1.0',lifespan=lifespan)
web_dir=Path(__file__).resolve().parents[3]/'frontend'
app.mount('/static',StaticFiles(directory=web_dir),name='static')

@app.get('/',include_in_schema=False)
def dashboard(): return FileResponse(web_dir/'index.html')

@app.get('/model-info')
def model_info():
    if predictor is None: raise HTTPException(503,'Model unavailable')
    c=predictor.config; n=predictor.model_info['window_samples']
    return {'model_version':predictor.model_info['version'],'threshold':predictor.model_info['threshold'],
            'prediction_horizon_minutes':predictor.manifest['prediction_horizon_minutes'],
            'required_samples':int(c['feature_window_days']*24*60/c['sampling_interval_minutes'])+n-1}

@app.get('/demo/telemetry')
def demo_telemetry():
    """Provide generated synthetic telemetry for the dashboard demonstration."""
    from .simulator import simulate_telemetry
    frame=simulate_telemetry(devices=1,days=14,seed=42)
    return {'filename':'synthetic-demo.csv','content_base64':base64.b64encode(frame.to_csv(index=False).encode('utf-8')).decode('ascii')}

@app.post('/workbook/preview')
def workbook_preview(request: WorkbookRequest):
    frame,sheets,selected=read_workbook(request)
    required=REQUIRED_TELEMETRY
    counts={str(k):int(v) for k,v in frame.device_id.dropna().astype(str).value_counts().items()} if 'device_id' in frame else {}
    ranges={}
    if 'device_id' in frame and 'timestamp' in frame:
        for device,group in frame.groupby(frame.device_id.astype(str)):
            dates=pd.to_datetime(group.timestamp,utc=True,errors='coerce').dropna()
            if len(dates): ranges[str(device)]={'start':dates.min().isoformat(),'end':dates.max().isoformat()}
    return {'sheets':sheets,'selected_sheet':selected,'rows':len(frame),'columns':list(frame.columns),'device_counts':counts,'device_ranges':ranges,
            'missing_columns':[c for c in required if c not in frame.columns],
            'devices':sorted(frame.device_id.dropna().astype(str).unique().tolist()) if 'device_id' in frame else []}

@app.post('/workbook/predict')
def workbook_predict(request: WorkbookRequest, device_id: str, create_alert: bool=True):
    frame,_,_=read_workbook(request)
    required=REQUIRED_TELEMETRY
    missing=[c for c in required if c not in frame.columns]
    if missing: raise HTTPException(422,'Missing columns: '+', '.join(missing))
    frame=frame[frame.device_id.astype(str)==device_id]
    if frame.empty: raise HTTPException(422,'Device not found in selected sheet')
    try:
        rows=[TelemetryRow(**r) for r in frame[required[1:]].to_dict('records')]
    except Exception as exc: raise HTTPException(422,f'Invalid telemetry rows: {exc}') from exc
    return predict(PredictionRequest(device_id=device_id,telemetry=rows,create_alert=create_alert))

@app.get('/health')
def health():
    return {'status':'ok','model_loaded':predictor is not None}

@app.post('/predict')
def predict(request: PredictionRequest):
    if predictor is None: raise HTTPException(503,'No trained model is loaded. Train the model and restart the API.')
    data=pd.DataFrame([{'device_id':request.device_id,**row.model_dump()} for row in request.telemetry])
    try: result=predictor.predict(data)
    except (ValueError,KeyError) as exc: raise HTTPException(422,str(exc)) from exc
    threshold=float(predictor.model_info['threshold'])
    cfg=predictor.config['alert_policy']
    alert=alert_for_prediction(device_id=request.device_id,generated_at=pd.Timestamp(result['generated_at']).to_pydatetime(),probability=result['probability'],threshold=threshold,model_version=result['model_version'],policy_version=cfg['version'],medium_probability=cfg['medium_probability'],contributing_features=[])
    record=store.create_or_update(alert) if request.create_alert and alert else None
    return {**result,'threshold':threshold,'alert':record}

@app.get('/alerts')
def list_alerts(limit: int=100): return store.list(max(1,min(limit,500)))

@app.get('/alerts/{alert_id}')
def get_alert(alert_id: str):
    item=store.get(alert_id)
    if item is None: raise HTTPException(404,'Alert not found')
    return item

@app.patch('/alerts/{alert_id}/status')
def update_alert_status(alert_id: str, request: StatusRequest):
    item=store.update_status(alert_id,request.status,request.actor,request.note)
    if item is None: raise HTTPException(404,'Alert not found')
    return item
