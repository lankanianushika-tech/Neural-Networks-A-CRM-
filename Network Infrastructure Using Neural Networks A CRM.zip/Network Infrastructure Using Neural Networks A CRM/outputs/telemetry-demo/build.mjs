import fs from 'node:fs/promises';
import { FileBlob, SpreadsheetFile } from '@oai/artifact-tool';

const input = 'D:/Ass/Sajindu-20261002T180426Z-1-001/UPDATED/FaultsAssignedToMyWG_1793184706052 data base.xlsx';
const workbook = await SpreadsheetFile.importXlsx(await FileBlob.load(input));
const rows = JSON.parse(await fs.readFile('outputs/telemetry-demo/telemetry.json', 'utf8'));
const sheet = workbook.worksheets.add('Synthetic Telemetry');
sheet.getRange(`A1:F${rows.length}`).values = rows;
sheet.getRange('A:A').format.columnWidth = 23;
sheet.getRange('B:B').format.columnWidth = 25;
sheet.getRange('C:F').format.columnWidth = 20;
sheet.getRange(`B2:B${rows.length}`).format.numberFormat = 'yyyy-mm-dd hh:mm:ss';
sheet.getRange(`C2:F${rows.length}`).format.numberFormat = '0.0000';
sheet.getRange('A1:F1').format.font.bold = true;
sheet.freezePanes.freezeRows(1);
const notes = workbook.worksheets.add('Read Me');
notes.getRange('A1:B5').values = [
  ['DEMONSTRATION DATA', 'The Synthetic Telemetry sheet is simulated, not measured network data.'],
  ['Original records', 'The original fault-record sheet is retained separately.'],
  ['Relationship', 'The simulated device and measurements do not describe the original fault records.'],
  ['Using the dashboard', 'Select the Synthetic Telemetry sheet and sim-device-0001, then run prediction.'],
  ['Interpretation', 'Results demonstrate software only; do not use them for real maintenance decisions.'],
];
notes.getRange('A:A').format.columnWidth = 24;
notes.getRange('B:B').format.columnWidth = 90;
notes.getRange('A1:A5').format.font.bold = true;
notes.getRange('B1:B5').format.wrapText = true;
const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save('outputs/telemetry-demo/Faults_with_synthetic_telemetry.xlsx');
const preview = await workbook.render({sheetName:'Synthetic Telemetry',range:'A1:F10',scale:1.5});
await fs.writeFile('outputs/telemetry-demo/preview.png',new Uint8Array(await preview.arrayBuffer()));
