import pandas as pd
import pytest

from predictive_maintenance.inference import Predictor


def telemetry(count):
    return pd.DataFrame({
        "device_id": "device-1",
        "timestamp": pd.date_range("2026-01-01", periods=count, freq="5min", tz="UTC"),
        "error_rate": 0.01, "latency_ms": 30.0, "temperature_c": 50.0, "traffic_load": 0.5,
    })


def test_inference_rejects_short_and_irregular_history_before_model_call():
    predictor = Predictor.__new__(Predictor)
    predictor.config = {"sampling_interval_minutes": 5, "feature_window_days": 7}
    predictor.model_info = {"window_samples": 144}
    with pytest.raises(ValueError, match="2159 consecutive samples"):
        predictor.predict(telemetry(2158))
    data = telemetry(2159)
    data.loc[1000:, "timestamp"] += pd.Timedelta(minutes=5)
    with pytest.raises(ValueError, match="Irregular sampling interval"):
        predictor.predict(data)
