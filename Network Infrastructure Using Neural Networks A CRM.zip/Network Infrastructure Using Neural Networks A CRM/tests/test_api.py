from datetime import datetime, timedelta, timezone
import asyncio

import httpx

from predictive_maintenance import api
from predictive_maintenance.store import AlertStore


class FakePredictor:
    model_info = {"version": "lstm-v1", "threshold": 0.5}
    config = {"alert_policy": {"version": "alert-policy-v1", "medium_probability": 0.35}}

    def predict(self, telemetry):
        return {"probability": 0.82, "model_version": "lstm-v1", "prediction_horizon_minutes": 1440,
                "generated_at": telemetry.timestamp.iloc[-1].isoformat()}


def test_prediction_and_mock_crm_routes(tmp_path, monkeypatch):
    monkeypatch.setattr(api, "store", AlertStore(tmp_path / "crm.sqlite3"))
    start = datetime(2026, 10, 1, tzinfo=timezone.utc)
    telemetry = [{"timestamp": (start + timedelta(minutes=5 * i)).isoformat(), "error_rate": .01,
                  "latency_ms": 30, "temperature_c": 50, "traffic_load": .5} for i in range(6)]
    monkeypatch.setattr(api, "predictor", FakePredictor())

    async def exercise_routes():
        transport = httpx.ASGITransport(app=api.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            result = (await client.post("/predict", json={"device_id": "sim-device-1", "telemetry": telemetry})).json()
            assert result["alert"]["priority"] == "high"
            alert_id = result["alert"]["alert_id"]
            repeat = (await client.post("/predict", json={"device_id": "sim-device-1", "telemetry": telemetry})).json()
            assert repeat["alert"]["alert_id"] == alert_id
            no_alert = await client.post("/predict", json={"device_id": "sim-device-2", "telemetry": telemetry, "create_alert": False})
            assert no_alert.status_code == 200 and no_alert.json()["alert"] is None
            assert len((await client.get("/alerts")).json()) == 1
            updated = await client.patch(f"/alerts/{alert_id}/status", json={"status": "reviewed"})
            assert updated.json()["status"] == "reviewed"
            assert (await client.get(f"/alerts/{alert_id}")).json()["status"] == "reviewed"
            assert (await client.get("/alerts/missing")).status_code == 404
            assert (await client.patch("/alerts/missing/status", json={"status": "reviewed"})).status_code == 404
            assert (await client.patch(f"/alerts/{alert_id}/status", json={"status": "invalid"})).status_code == 422
            invalid = [{**telemetry[0], "traffic_load": 2}]
            assert (await client.post("/predict", json={"device_id": "sim-device-1", "telemetry": invalid})).status_code == 422

    asyncio.run(exercise_routes())
