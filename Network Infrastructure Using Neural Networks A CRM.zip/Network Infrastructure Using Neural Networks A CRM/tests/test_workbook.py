import base64
import io

import pandas as pd
from fastapi.testclient import TestClient

from predictive_maintenance import api


def test_workbook_sheet_selection_and_invalid_files():
    data = io.BytesIO()
    with pd.ExcelWriter(data, engine="openpyxl") as writer:
        pd.DataFrame({"device_id": ["device-1"], "timestamp": ["2026-01-01T00:00:00Z"],
                      "error_rate": [0.1], "latency_ms": [20], "temperature_c": [40],
                      "traffic_load": [0.5]}).to_excel(writer, sheet_name="Telemetry", index=False)
        pd.DataFrame({"other": [1]}).to_excel(writer, sheet_name="Other", index=False)
    body = {"filename": "sample.xlsx", "content_base64": base64.b64encode(data.getvalue()).decode(), "sheet": "Telemetry"}
    with TestClient(api.app) as client:
        response = client.post("/workbook/preview", json=body)
        assert response.status_code == 200
        assert response.json()["sheets"] == ["Telemetry", "Other"]
        assert response.json()["device_counts"] == {"device-1": 1}
        assert not response.json()["missing_columns"]
        assert "device_id" in client.post("/workbook/preview", json={**body, "sheet": "Other"}).json()["missing_columns"]
        assert client.post("/workbook/preview", json={**body, "sheet": "missing"}).status_code == 422
        assert client.post("/workbook/preview", json={**body, "content_base64": "invalid!"}).status_code == 422
        bad_zip = base64.b64encode(b"not an excel file").decode()
        assert client.post("/workbook/preview", json={**body, "content_base64": bad_zip}).status_code == 422
        duplicate = base64.b64encode(b"device_id, DEVICE_ID\na,b\n").decode()
        assert client.post("/workbook/preview", json={"filename": "sample.csv", "content_base64": duplicate}).status_code == 422


def test_synthetic_demo_provides_usable_telemetry():
    with TestClient(api.app) as client:
        demo = client.get('/demo/telemetry')
        assert demo.status_code == 200
        preview = client.post('/workbook/preview', json=demo.json())
        assert preview.status_code == 200
        result = preview.json()
        assert not result['missing_columns']
        assert result['device_counts']['sim-device-0001'] >= 2159


def test_preview_selects_compatible_sheet_when_first_sheet_is_not_telemetry():
    data = io.BytesIO()
    with pd.ExcelWriter(data, engine='openpyxl') as writer:
        pd.DataFrame({'ID': [1], 'Cause Of Fault': ['fault']}).to_excel(writer, sheet_name='Faults', index=False)
        pd.DataFrame({'device_id':['sim-1'], 'timestamp':['2026-01-01T00:00:00Z'], 'error_rate':[.01],
                      'latency_ms':[30], 'temperature_c':[50], 'traffic_load':[.5]}).to_excel(writer, sheet_name='Synthetic Telemetry', index=False)
    body = {'filename':'example.xlsx', 'content_base64':base64.b64encode(data.getvalue()).decode()}
    with TestClient(api.app) as client:
        response = client.post('/workbook/preview', json=body)
        assert response.status_code == 200
        assert response.json()['selected_sheet'] == 'Synthetic Telemetry'
        assert response.json()['devices'] == ['sim-1']
        assert client.post('/workbook/preview', json={**body, 'sheet':'Faults'}).json()['selected_sheet'] == 'Faults'
